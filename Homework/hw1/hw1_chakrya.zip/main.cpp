/**
Chakrya Ros
Homework 1
This is main function to test functions
*/
#include <iostream>
#include "Player.h"
#include "Maze.h"

using namespace std;

int main()
{
	// Position Pos;
	// Pos.row = 0;
	// Pos.col= 1;
	// Player player("Chakrya", false);
	// player.SetPosition({0,0});
	// cout<<"Player's name: "<<player.get_name()<<endl;
	// cout<<player.get_points()<<endl;
	// player.ChangePoints(10);
	// player.Stringify();
	// cout<<player.ToRelativePosition(Pos)<<endl;

	 //SquareType sq;
	//sq = SquareType::Wall;
	// string s1 = SquareTypeStringify(sq);
	 // sq = SquareType::Enemy;
	 // string s2 = SquareTypeStringify(sq);
	 // sq = SquareType::Human;
	 // string s3 = SquareTypeStringify(sq);
	 // sq = SquareType::Exit;
	 //s2 =s3;
	// string s4 = SquareTypeStringify(sq);
	// sq = SquareType::Treasure;
	// string s5 = SquareTypeStringify(sq);
	// cout<<"Wall: "<<s1<<endl;
	//cout<<"Enemy: "<<s2<<endl;
	// cout<<"Human: "<<s3<<endl;
	// cout<<"Exit: "<<s4<<endl;
	// cout<<"Treasure: "<<s5<<endl;

	Maze game;
	Position Pos;
	Board b;
	Pos.row =0;
	Pos.col =0;
	Player *player1 = new Player("Yanit", false);
	//string move = player1->ToRelativePosition(Pos);
	b.get_square_value(Pos);
	
	cout << b << endl;
	game.NewGame(player1, 2);

	// Player * p;
	// while(!game.IsGameOver())
	// {
	// 	 p = game.GetNextPlayer();
	// }
	// game.TakeTurn(p);
	 game.GenerateReport();
	

	//cout<<game.IsGameOver();

	

	return 0;
}



























