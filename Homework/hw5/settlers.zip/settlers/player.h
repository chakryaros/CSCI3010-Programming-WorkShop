#ifndef PLAYER_H
#define PLAYER_H

#include <iostream>

using namespace std;

class Player
{
public:
    Player(int gold, const bool is_human, int wood, int stone);


    int get_points()const {return points_;}
    bool is_human() const {return is_human_;}
    void ChangePoints(const int x);

    //get and set wood
     int get_wood() { return wood_amount_;}
     void set_wood(int wood) { wood_amount_ = wood;}

     //get and set stone
     int get_stone() { return stone_amount_;}
     void set_stone(int stone) { stone_amount_ = stone;}

     //get and set stone
     int get_Gold() { return gold_;}
     void set_Gold(int gold) { gold_ = gold;}

     //to check if the play have enough resource to build house
     bool afford_resource();

private:

    int points_;
    bool is_human_;
    int wood_amount_, stone_amount_, gold_;
};

#endif // PLAYER_H
