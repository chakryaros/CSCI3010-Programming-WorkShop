#include <iostream>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QDebug>
#include <QTimer>
#include <QColor>
#include <QInputDialog>
#include <vector>
#include <QMessageBox>

#include <iostream>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "gamecell.h"

using namespace std;

// Names:
// Charkya Ros
// James McDonald

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    scene = new QGraphicsScene;
    ui->setupUi(this);
    // get view from gameView
    QGraphicsView * view = ui->gameView;
    view->setScene(scene);
    view->setSceneRect(0,0,view->frameSize().width(),view->frameSize().height());



    // Display the message how to play game

       QMessageBox MsgBox;
       MsgBox.setText("Welcome to Settlers!\n\n"
                      "In this game, two players compete to reach 1000 gold before the other.\n\n"
                      "To collect gold you may spend your resources to build structures on new tiles.\n\n"
                      "A house costs 30 wood and will return all of the resources on that tile to you each turn.\n\n"
                      "A wall costs 30 stone and blocks your opponent's expansion but yeilds no resources each turn.\n\n"
                      "Each player may purchase a Spy for 150 gold that will allow you to steal an opponents tile.");
       MsgBox.exec();

    //set player1 resource
    player_one = new Player(0, true, 50, 10);
    ui->Money->setText(QString("Gold: ") + QString::number(player_one->get_Gold()));
    ui->Wood->setText(QString("Wood: ") + QString::number(player_one->get_wood()));
    ui->stone->setText(QString("Stone: ") + QString::number(player_one->get_stone()));

    //set player1 resource
    player_two = new Player(0, true, 50, 10);
    ui->Money2->setText(QString("Gold: ") + QString::number(player_two->get_Gold()));
    ui->wood2->setText(QString("Wood: ") + QString::number(player_two->get_wood()));
    ui->stone2->setText(QString("Stone: ") + QString::number(player_two->get_stone()));

    /* initialize random seed: */
    srand(time(NULL));



    //Create and draw game cells:

    QColor white(255,255,255);

    QString test_str;

    test_str.fromStdString("Test text.");

    //Populate our game_grid_ (9w x 8h):
    for(int i = 0; i < 9; i++){

        for(int n = 0; n < 8; n++){

            GameCell * gc = new GameCell(i*100,n*100);
            gc->setColor(white);
            scene->addItem(gc);
            scene->addText(test_str);
            connect(gc, &GameCell::CellClicked, this, &MainWindow::CellClickedSlot);
            game_grid_[i][n] = gc;
            gc->updateState();
        }

    }

    //Set the two castle squares:
    game_grid_[8][0]->set_structure(Castle2);
    game_grid_[8][0]->set_owner(2);
    game_grid_[8][0]->set_is_owned(true);
    game_grid_[8][0]->updateState();

    game_grid_[0][7]->set_structure(Castle1);
    game_grid_[0][7]->set_owner(1);
    game_grid_[0][7]->set_is_owned(true);
    game_grid_[0][7]->updateState();

    //Draw grid lines:
    int x_pos = 0;
    int y_pos = 0;

    while (y_pos <= ui->gameView->frameSize().rheight()){

        //Draw vertical lines:
        while (x_pos <= ui->gameView->frameSize().rwidth()){
            scene->addLine(x_pos, 0, x_pos, ui->gameView->frameSize().rheight());
            x_pos += 100;
        }
        //Draw horizontal lines:
        scene->addLine(0, y_pos, ui->gameView->frameSize().rwidth(), y_pos);
        y_pos += 100;
    }

    //Connect buttons:
    connect(ui->BuildWallButton, &QAbstractButton::pressed, this, &MainWindow::Build_Wall_clicked);
    connect(ui->BuildHouseButton, &QAbstractButton::pressed, this, &MainWindow::Build_House_clicked);
    connect(ui->PurchaseButton, &QAbstractButton::pressed, this, &MainWindow::Purchase_Spy_clicked);
    connect(ui->StartGame, &QAbstractButton::pressed, this, &MainWindow::StartGame_clicked);
    connect(ui->EndButton, &QAbstractButton::pressed, this, &MainWindow::End_Turn_clicked);
    connect(ui->AIButton, &QAbstractButton::pressed, this, &MainWindow::Take_AI_Turn2_clicked);
    connect(ui->AIButton_2, &QAbstractButton::pressed, this, &MainWindow::Take_AI_Turn1_clicked);

    //We should not start in build mode:
    build_mode_ = false;
    spy_mode = false;

    //Player one always starts:
    current_player_ = 1;
    player_up = player_one;

}

MainWindow::~MainWindow()
{
    delete ui;
}

//write a function to display message
//that player can't build a house because player doesn't have
//enough resource.
void MainWindow::display_ResourceMessage()
{
    QString test_str;
    QTextStream out(&test_str);
    if(current_player_ == 1)
    {
        out << "Player: "<<current_player_<<"\n";
        out << "Money: "<<player_one->get_Gold()<<"\n";
        out << "Wood: "<<player_one->get_wood()<<"\n";
        out << "Stone: "<<player_one->get_stone()<<"\n";
        out << "You do not have the resources to build a house!";
        QMessageBox MsgBox;
        MsgBox.setText(test_str);
        MsgBox.exec();
    }
    else
    {
        out << "Player: "<<current_player_<<"\n";
        out << "Money: "<<player_two->get_Gold()<<"\n";
        out << "Wood: "<<player_two->get_wood()<<"\n";
        out << "Stone: "<<player_two->get_stone()<<"\n";
        out << "You do not have the resources to build a house!";
        QMessageBox MsgBox;
        MsgBox.setText(test_str);
        MsgBox.exec();
    }

}

//write a fucntion to display message that
// player do not have enough momey to spy
void MainWindow::display_affordMoneyForSpy()
{
    QMessageBox MsgBox;
    MsgBox.setText("You do not have enough money!");
    MsgBox.exec();
}

void MainWindow::Build_Wall_clicked(){

    qDebug() << "You clicked build wall.";

    if(!build_mode_){
        build_mode_ = true;
        qDebug() << "Build mode on.";
        this->getMoves();
        to_build_ = Wall;

    }
    else{

        build_mode_ = false;
        qDebug() << "Build mode off.";

        QColor white(255,255,255);
        QColor blue(153,204,255);
        QColor red(255,204,204);

        //Iterate thru all the cells and set them to their original color:
        for(int cols = 0; cols < 9; cols++){

            for(int rows = 0; rows < 8; rows++){

                switch(game_grid_[cols][rows]->get_owner()){

                    case 0:
                        game_grid_[cols][rows]->setColor(white);
                        break;

                    case 1:
                        game_grid_[cols][rows]->setColor(blue);
                        break;

                    case 2:
                        game_grid_[cols][rows]->setColor(red);
                        break;

                } // end switch

            } //end for rows

        } //end for cols

        to_build_ = Empty;

    }//end else


}

void MainWindow::Build_House_clicked(){

    qDebug() << "You clicked build house.";

    if(!build_mode_){
        build_mode_ = true;
        qDebug() << "Build mode on.";
        this->getMoves();
        to_build_ = House;
        ui->OutputBox->appendPlainText("Build mode actived.  Click on the tile on which you would like to build a HOUSE.");

    }
    else{

          this->exitBuildMode();

    }//end else

}

void MainWindow::Purchase_Spy_clicked(){

    qDebug() << "You clicked purchase spy.";

    if(!spy_mode){

        //make sure we escape build mode:
        this->exitBuildMode();

        if(player_up->get_Gold()>=150){
            spy_mode = true;
            this->getMoves();
            ui->OutputBox->appendPlainText("Click on the opponent's tile you would like to steal.");
        }
        else{
            ui->OutputBox->appendPlainText("You cannot afford a spy.");
        }

    }
    else{

        spy_mode = false;
        this->exitBuildMode();

    }

}

void MainWindow::CellClickedSlot(GameCell * gc, Qt::KeyboardModifiers modifier, Qt::MouseButton button){

    qDebug() << "You clicked tile " << gc->get_x() << ", " << gc->get_y() << ": it is owned by: " << gc->get_owner();

    int current_wood, current_gold, current_stone;

    current_gold = player_up->get_Gold();
    current_wood = player_up->get_wood();
    current_stone = player_up->get_stone();

    if(build_mode_){
        int to_deduct;
        bool has_enough = false;
        if(to_build_ == House){
            has_enough = current_wood >= 50;
            to_deduct = 50;
            if (has_enough){
                int acc = current_wood - 50;
                player_up->set_wood(acc);
                ui->OutputBox->appendPlainText("You spent 50 wood to construct a house.");

            }
        }
        else if(to_build_ == Wall ){
            has_enough = current_stone >= 30;
            to_deduct = 30;
            if (has_enough){
                int acc = current_stone - 30;
                player_up->set_stone(acc);
                ui->OutputBox->appendPlainText("You spent 30 stone to construct a wall.");
            }
        }

        //Update resource display after purchase.
        this->updateResources();

        if(gc->get_is_legal()){
            qDebug() << "Attempting to build.";

            if(has_enough){
                gc->set_owner(current_player_);
                gc->set_is_owned(true);
                gc->set_structure(to_build_);
                gc->updateState();
                this->getMoves();
                ui->OutputBox->appendPlainText("Construction successful!");
            }
            else{
                ui->OutputBox->appendPlainText("You do not have enough resources to build that!");
            }
        }
        else{
            ui->OutputBox->appendPlainText("You can only build on tiles adjacent to ones you already own.");
        }
    }
    else if(spy_mode){

        if((gc->get_owner() != current_player_) && (gc->get_owner() != 0)){

            if(gc->get_structure()!=Castle1 && gc->get_structure()!=Castle2){
                gc->set_owner(current_player_);
                spy_mode = false;
                this->exitBuildMode();
                ui->OutputBox->appendPlainText("Tile stolen!");
                int g_acc = player_up->get_Gold();
                g_acc -= 150;
                player_up->set_Gold(g_acc);
                this->updateResources();
            }
            else{

                ui->OutputBox->appendPlainText("You may not steal an opponent's castle!");

            }
        }
        else{

            ui->OutputBox->appendPlainText("You may only steal an opponent's tile.");

        }

    }

}

void MainWindow::getMoves(){

    //Store the color green for legal moves:
    QColor c(153,255,204);

    //Here we will check the current game mode:
    if (build_mode_){

        //Iterate through all cells
        for(int cols = 0; cols < 9; cols++){

            for(int rows = 0; rows < 8; rows++){

                qDebug() << "Evaluating tile " << cols << ", " << rows;
                //If the current player owns this cell:
                if(game_grid_[cols][rows]->get_owner() == current_player_){

                    //We need to look in all directions to see if there is an unowned square and mark it as a legal move:

                    //Look left:

                    //If we're not on the left edge of the board:
                    if(cols > 0){

                        //if nobody owns it:
                        if(!game_grid_[cols-1][rows]->get_is_owned()){
                            qDebug() << "Found a legal move at: " << cols-1 << ", " << rows;
                            game_grid_[cols-1][rows]->set_is_legal(true);
                            game_grid_[cols-1][rows]->setColor(c);

                        }

                    }// End look left

                    //Look up-left:
                    //If we're not on the edge of the map:
                    if(cols > 0 && rows > 0){

                        //if nobody owns it:
                        if(!game_grid_[cols-1][rows-1]->get_is_owned()){
                            qDebug() << "Found a legal move at: " << cols-1 << ", " << rows-1;
                            game_grid_[cols-1][rows-1]->set_is_legal(true);
                            game_grid_[cols-1][rows-1]->setColor(c);

                        }

                    }//End look up-left

                    //Look up:
                    //If we're not on the top of the map:
                    if(rows > 0){

                        //if nobody owns it:
                        if(!game_grid_[cols][rows-1]->get_is_owned()){
                            qDebug() << "Found a legal move at: " << cols << ", " << rows-1;
                            game_grid_[cols][rows-1]->set_is_legal(true);
                            game_grid_[cols][rows-1]->setColor(c);

                        }

                    }// End look up

                    //Look up-right:
                    //If we're not on the edge of the map:
                    if(cols < 8 && rows > 0){

                        //if nobody owns it:
                        if(!game_grid_[cols+1][rows-1]->get_is_owned()){
                            qDebug() << "Found a legal move at: " << cols+1 << ", " << rows-1;
                            game_grid_[cols+1][rows-1]->set_is_legal(true);
                            game_grid_[cols+1][rows-1]->setColor(c);

                        }

                    }//End look up-right

                    //Look right:
                    //If we're not on the right edge of the board:
                    if(cols < 8){

                        //if nobody owns it:
                        if(!game_grid_[cols+1][rows]->get_is_owned()){
                            qDebug() << "Found a legal move at: " << cols+1 << ", " << rows;
                            game_grid_[cols+1][rows]->set_is_legal(true);
                            game_grid_[cols+1][rows]->setColor(c);

                        }

                    }// End look right

                    //Look down-right:
                    //If we're not on the right-bottom edge of the board:
                    if(cols < 8 && rows < 7){

                        //if nobody owns it:
                        if(!game_grid_[cols+1][rows+1]->get_is_owned()){
                            qDebug() << "Found a legal move at: " << cols+1 << ", " << rows+1;
                            game_grid_[cols+1][rows+1]->set_is_legal(true);
                            game_grid_[cols+1][rows+1]->setColor(c);

                        }

                    }// End down right

                    //Look down:
                    //If we're not on the bottom edge of the board:
                    if(rows < 7){

                        //if nobody owns it:
                        if(!game_grid_[cols][rows+1]->get_is_owned()){
                            qDebug() << "Found a legal move at: " << cols << ", " << rows+1;
                            game_grid_[cols][rows+1]->set_is_legal(true);
                            game_grid_[cols][rows+1]->setColor(c);

                        }

                    }// End look down

                    //Look down-left:
                    //If we are not in the bottom left corner:
                    if(cols > 0 && rows < 7){

                        //if nobody owns it:
                        if(!game_grid_[cols-1][rows+1]->get_is_owned()){
                            qDebug() << "Found a legal move at: " << cols-1 << ", " << rows+1;
                            game_grid_[cols-1][rows+1]->set_is_legal(true);
                            game_grid_[cols-1][rows+1]->setColor(c);

                        }

                    }// End look down-left

                }//End if we own this cell

            }//End iterate thru rows

        }//End iterate thru cols

        //Draw everything:
        update();

    }
    else if(spy_mode){

        for(int cols = 0; cols < 9; cols++){

            for(int rows = 0; rows < 8; rows++){

                if((game_grid_[cols][rows]->get_is_owned()) && (game_grid_[cols][rows]->get_owner() != current_player_)){

                    if(game_grid_[cols][rows]->get_structure() != Castle1 && game_grid_[cols][rows]->get_structure() != Castle2){

                        game_grid_[cols][rows]->set_is_legal(true);

                    }

                }

            }
        }
    }


}

void MainWindow::End_Turn_clicked(){

    //Iterate through all tiles and add resources owned to player's total:
    int g_acc = 0;
    int s_acc = 0;
    int w_acc = 0;

    QString test_str;
    QTextStream out(&test_str);

    for(int cols = 0; cols < 9; cols++){

        for(int rows = 0; rows < 8; rows++){

            if((game_grid_[rows][cols]->get_owner() == current_player_) && (game_grid_[rows][cols]->get_structure() != Wall)){

                qDebug() << "Grid " << rows << ", " << cols << " is owned by this player and has: " << game_grid_[rows][cols]->get_gold() << " gold, " << game_grid_[rows][cols]->get_wood() << " wood, and " << game_grid_[rows][cols]->get_stone() << " stone.";
                g_acc += game_grid_[rows][cols]->get_gold();
                w_acc += game_grid_[rows][cols]->get_wood();
                s_acc += game_grid_[rows][cols]->get_stone();

            }

        }
    }

    qDebug() << "g_acc: " << g_acc << " s_acc: " << s_acc << " w_acc: " << w_acc;

    if(current_player_ == 1){


        qDebug() << "Entering player 1 end conditional.";
        out << "Player one collected " << g_acc << " gold, " << w_acc << " wood, and " << s_acc << " stone this turn.";
        g_acc += player_one->get_Gold();
        player_one->set_Gold(g_acc);
        w_acc += player_one->get_wood();
        player_one->set_wood(w_acc);
        s_acc += player_one->get_stone();
        player_one->set_stone(s_acc);


        ui->OutputBox->appendPlainText(test_str);

        ui->Money->setText(QString("Gold: ") + QString::number(player_one->get_Gold()));
        ui->Wood->setText(QString("Wood: ") + QString::number(player_one->get_wood()));
        ui->stone->setText(QString("Stone: ") + QString::number(player_one->get_stone()));

        if(player_one->get_Gold() >= 1000){

            QMessageBox MsgBox;
            MsgBox.setText("Player one has won the game!");
            MsgBox.exec();
            ui->OutputBox->appendPlainText("Player 1 wins!");
            this->StartGame_clicked();

        }


        qDebug() << "Completed player 1 end conditional.";

    }
    else{

        out << "Player two collected " << g_acc << " gold, " << w_acc << " wood, and " << s_acc << " stone this turn.";
        g_acc += player_two->get_Gold();
        player_two->set_Gold(g_acc);
        w_acc += player_two->get_wood();
        player_two->set_wood(w_acc);
        s_acc += player_two->get_stone();
        player_two->set_stone(s_acc);

        ui->Money2->setText(QString("Gold: ") + QString::number(player_two->get_Gold()));
        ui->wood2->setText(QString("Wood: ") + QString::number(player_two->get_wood()));
        ui->stone2->setText(QString("Stone: ") + QString::number(player_two->get_stone()));

        ui->OutputBox->appendPlainText(test_str);

        if(player_two->get_Gold() >= 1000){

            QMessageBox MsgBox;
            MsgBox.setText("Player two has won the game!");
            MsgBox.exec();
            ui->OutputBox->appendPlainText("Player 2 wins!");
            this->StartGame_clicked();

        }

    }

    //Exit build mode if it is activated:
    if(build_mode_){

        this->exitBuildMode();
        qDebug() << "Disabling build mode.";

    }

    //Swap players:
    if(current_player_ == 1){
        current_player_ = 2;
        player_up = player_two;
        ui->OutputBox->appendPlainText("Player 2's turn!");
        qDebug() << "Switching to player 2.";
    }
    else {
        current_player_ = 1;
        player_up = player_one;
        ui->OutputBox->appendPlainText("Player 1's turn!");
        qDebug() << "Switching to player 1.";
    }
}
void MainWindow::StartGame_clicked(){

    qDebug() << "You clicked Start New Game.";
    QColor white(255,255,255);

    QString test_str;

    test_str.fromStdString("Test text.");
    for(int i = 0; i < 9; i++){

        for(int n = 0; n < 8; n++){

            GameCell * gc = new GameCell(i*100,n*100);
            gc->setColor(white);
            scene->addItem(gc);
            scene->addText(test_str);
            connect(gc, &GameCell::CellClicked, this, &MainWindow::CellClickedSlot);
            game_grid_[i][n] = gc;
            gc->updateState();
        }

    }

    //Set the two castle squares:
    game_grid_[8][0]->set_structure(Castle2);
    game_grid_[8][0]->set_owner(2);
    game_grid_[8][0]->set_is_owned(true);
    game_grid_[8][0]->updateState();

    game_grid_[0][7]->set_structure(Castle1);
    game_grid_[0][7]->set_owner(1);
    game_grid_[0][7]->set_is_owned(true);
    game_grid_[0][7]->updateState();

    ui->OutputBox->appendPlainText("New game started!");
    current_player_ = 1;
    player_up = player_one;

    player_one->set_Gold(0);
    player_one->set_stone(10);
    player_one->set_wood(50);
    player_two->set_Gold(0);
    player_two->set_stone(10);
    player_two->set_wood(50);
    this->updateResources();


}

void MainWindow::exitBuildMode(){

        build_mode_ = false;
        qDebug() << "Build mode off.";
        //ui->OutputBox->appendPlainText("Build mode deactivated.");
        QColor white(255,255,255);
        QColor blue(153,204,255);
        QColor red(255,204,204);

        //Iterate thru all the cells and set them to their original color:
        for(int cols = 0; cols < 9; cols++){

            for(int rows = 0; rows < 8; rows++){

                game_grid_[cols][rows]->set_is_legal(false);

                switch(game_grid_[cols][rows]->get_owner()){

                case 0:
                    game_grid_[cols][rows]->setColor(white);
                    break;

                case 1:
                    game_grid_[cols][rows]->setColor(blue);
                    break;

                case 2:
                    game_grid_[cols][rows]->setColor(red);
                    break;

                } // end switch

            } //end for rows

        } //end for cols

        to_build_ = Empty;

    }

void MainWindow::updateResources(){

    ui->Money->setText(QString("Gold: ") + QString::number(player_one->get_Gold()));
    ui->Wood->setText(QString("Wood: ") + QString::number(player_one->get_wood()));
    ui->stone->setText(QString("Stone: ") + QString::number(player_one->get_stone()));
    ui->Money2->setText(QString("Gold: ") + QString::number(player_two->get_Gold()));
    ui->wood2->setText(QString("Wood: ") + QString::number(player_two->get_wood()));
    ui->stone2->setText(QString("Stone: ") + QString::number(player_two->get_stone()));

}

void MainWindow::Take_AI_Turn2_clicked(){

    if(current_player_ == 2){

        //Take AI turn:

        //Priority should be building a house:
        while(player_two->get_wood() >= 50){

            build_mode_ = true;
            to_build_ = House;
            this->getMoves();
            int acc=0;
            GameCell * gc;

            for(int cols = 0; cols < 9; cols++){

                for(int rows = 0; rows < 8; rows++){

                    //if this move is legal
                    if(game_grid_[cols][rows]->get_is_legal()){

                        if(game_grid_[cols][rows]->get_gold() > acc){

                            acc = game_grid_[cols][rows]->get_gold();
                            gc = game_grid_[cols][rows];

                        }

                    }
                }
            }

            gc->set_owner(2);
            gc->set_is_owned(true);
            gc->set_is_legal(false);
            gc->set_structure(House);
            gc->updateState();
            player_two->set_wood(player_two->get_wood()-50);

        }

        this->exitBuildMode();
        this->updateResources();

        //If p2 is behind and has money they should try and steal p1's best tile:

        if(player_two->get_Gold() > 150 && player_two->get_Gold() < player_one->get_Gold()){

            spy_mode = true;
            this->getMoves();
            int acc=0;
            GameCell * gc;

            for(int cols = 0; cols < 9; cols++){

                for(int rows = 0; rows < 8; rows++){

                    //if this move is legal
                    if(game_grid_[cols][rows]->get_is_legal()){

                        if(game_grid_[cols][rows]->get_gold() > acc){

                            acc = game_grid_[cols][rows]->get_gold();
                            gc = game_grid_[cols][rows];

                        }

                    }
                }
            }

            gc->set_owner(2);
            gc->set_is_owned(true);
            gc->set_is_legal(false);
            gc->set_structure(House);
            gc->updateState();
            player_two->set_Gold(player_two->get_Gold()-150);
            spy_mode = false;
            this->exitBuildMode();

        }

        this->End_Turn_clicked();

    }
    else {

        ui->OutputBox->appendPlainText("It needs to be player 2's turn.");

    }

    //AI player should try to steal a tile if player 1 is ahead and they have money


}

void MainWindow::Take_AI_Turn1_clicked(){

    if(current_player_ == 1){

        //Take AI turn:

        //Priority should be building a house:
        while(player_one->get_wood() >= 50){

            build_mode_ = true;
            to_build_ = House;
            this->getMoves();
            int acc=0;
            GameCell * gc;

            for(int cols = 0; cols < 9; cols++){

                for(int rows = 0; rows < 8; rows++){

                    //if this move is legal
                    if(game_grid_[cols][rows]->get_is_legal()){

                        if(game_grid_[cols][rows]->get_gold() > acc){

                            acc = game_grid_[cols][rows]->get_gold();
                            gc = game_grid_[cols][rows];

                        }

                    }
                }
            }

            gc->set_owner(1);
            gc->set_is_owned(true);
            gc->set_is_legal(false);
            gc->set_structure(House);
            gc->updateState();
            player_one->set_wood(player_one->get_wood()-50);

        }

        this->exitBuildMode();
        this->updateResources();

        //If p1 is behind and has money they should try and steal p2's best tile:

        if(player_one->get_Gold() > 150 && player_one->get_Gold() < player_two->get_Gold()){

            spy_mode = true;
            this->getMoves();
            int acc=0;
            GameCell * gc;

            for(int cols = 0; cols < 9; cols++){

                for(int rows = 0; rows < 8; rows++){

                    //if this move is legal
                    if(game_grid_[cols][rows]->get_is_legal()){

                        if(game_grid_[cols][rows]->get_gold() > acc){

                            acc = game_grid_[cols][rows]->get_gold();
                            gc = game_grid_[cols][rows];

                        }

                    }
                }
            }

            gc->set_owner(1);
            gc->set_is_owned(true);
            gc->set_is_legal(false);
            gc->set_structure(House);
            gc->updateState();
            player_one->set_Gold(player_one->get_Gold()-150);
            spy_mode = false;
            this->exitBuildMode();

        }

        this->End_Turn_clicked();

    }
    else {

        ui->OutputBox->appendPlainText("It needs to be player 1's turn.");

    }


}
