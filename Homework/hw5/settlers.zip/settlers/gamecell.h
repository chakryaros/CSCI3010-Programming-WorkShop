#ifndef GAMECELL_H
#define GAMECELL_H

#include <QColor>
#include <QGraphicsItem>
#include <QWidget>
#include <QFrame>
#include <QHBoxLayout>
#include <QPushButton>
#include "player.h"


/*
 * Things to think about with our game cells:
 *
 * -we need to override the boundingRect() and shape() methods to ensure they return the correct collision detection for this object
 */

enum Structure {

    Castle1,
    Castle2,
    House,
    Wall,
    Empty

};

class GameCell :  public QObject, public QGraphicsItem {

    Q_OBJECT

public:
    GameCell(int x, int y); //Constructor

    int get_x()  { return x_; }  // inline member function
    int get_y() { return y_; }  // inline member function
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *item, QWidget *widget) override;



    //generate random resource
    void randomResource();

    void set_owner(int i){ owner_ = i; }
    void set_structure(Structure s){ structure_ = s; }
    Structure get_structure(){ return structure_; }
    bool get_is_owned(){ return is_owned_; }
    void set_is_owned(bool b){ is_owned_ = b; }
    int get_owner(){ return owner_; }
    void set_is_legal(bool b){ is_legal_ = b; }
    bool get_is_legal(){ return is_legal_; }
    int get_gold(){ return gold_; }
    int get_wood(){ return wood_; }
    int get_stone(){ return stone_; }

    void setColor(QColor c);
    void updateState();

    QRectF boundingRect() const override;
    QPainterPath shape() const override;



signals:
    void CellClicked(GameCell * gc, Qt::KeyboardModifiers modifier, Qt::MouseButton button);

protected:

   void mousePressEvent(QGraphicsSceneMouseEvent *event) override;

private:
  int wood_, stone_, gold_;
  int productivity_modifier_; //use this to determine how much a house on this square generates
  int x_;
  int y_;
  Structure structure_;

  QColor color_;
  int owner_; //0 = unowned, 1 = player 1, 2 = player 2
  bool is_owned_;

  //Used to mark legal moves:
  bool is_legal_;
  QString display_string_;

};

#endif // GAMECELL_H
