#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "player.h"
#include "gamecell.h"
#include <QGraphicsScene>
#include <QMainWindow>


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void display_ResourceMessage();
    void display_affordMoneyForSpy();
    void getMoves();
    void exitBuildMode();
    void set_to_build(Structure s){ to_build_ = s; }

    void updateResources();

private slots:
    void Build_Wall_clicked();
    void Build_House_clicked();
    void Purchase_Spy_clicked();
    void CellClickedSlot(GameCell * gc, Qt::KeyboardModifiers modifier, Qt::MouseButton button);
    void End_Turn_clicked();
    void Take_AI_Turn2_clicked();
    void Take_AI_Turn1_clicked();




    void StartGame_clicked();

private:
    Ui::MainWindow *ui;
    QGraphicsScene *scene;
    Player * player_one;
    Player * player_two;
    GameCell * game_grid_[9][8];
    bool build_mode_;
    int current_player_; //this should only ever been one or two
    bool spy_mode;
    Structure to_build_;
    Player * player_up;

};

#endif // MAINWINDOW_H
