#include "gamecell.h"
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <QtWidgets>
#include <sstream>

using namespace std;

GameCell::GameCell(int x, int y)
{
    x_=x;
    y_=y;
    is_owned_ = false;
    structure_ = Empty;
    randomResource();
    owner_ = 0;
}

QRectF GameCell::boundingRect() const {

    return QRectF(x_, y_, 100, 100);

}

QPainterPath GameCell::shape() const {

    QPainterPath path;
    path.addRect(x_, y_, 100, 100);
    return path;

}
//create a function to random resource on the gamecell
void GameCell::randomResource()
{

    wood_ = rand() %50 + 1; //random from 1 to 50
    stone_ = rand() %50 + 1; //radom from 1 to 50
    gold_ = rand() %30 + 1; //random from 1 to 20
}

void GameCell::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    Q_UNUSED(widget);
    QBrush b = painter->brush();
    painter->setBrush(QBrush(color_));
    painter->drawRect(QRect(this->x_, this->y_, 100, 100));
    painter->setBrush(b);

    //Adjust this to get margins:
    painter->drawText(this->boundingRect(), Qt::AlignLeft, display_string_);
}
void GameCell::mousePressEvent(QGraphicsSceneMouseEvent *event)
{

    qDebug() << "This method automatically called when the GridCell is clicked!";
    emit CellClicked(this, event->modifiers(), event->button());
    //QColor c(153,255,204);
    //this->color_= c;
    update();

}

void GameCell::setColor(QColor c){

    color_ = c;
    update();

}

//This method will update the color and text of a cell
void GameCell::updateState(){

    QString test_str;
    QTextStream out(&test_str);

    if(is_owned_){

        if(owner_ == 1){

            QColor c(153,204,255);
            this->setColor(c);

        }
        else if(owner_ == 2){

            QColor c(255,204,204);
            this->setColor(c);

        }

        out << "P" << owner_ << " ";

        switch(structure_){

            case Castle1:
                out << "Castle";
                break;
            case Castle2:
                out << "Castle";
                break;
            case House:
                out << "House";
                break;
            case Wall:
                out << "Wall";
                break;
            default:
                out << "Empty";
                break;
        }

    }

    out << "\nResources:\nWood: " << wood_ << "\nStone: " << stone_ << "\n$: " << gold_ << "\n";
    display_string_ = test_str;

}
