#include "player.h"



/**
    Player construction to declare the new player
    @ string name, to get player's name
    @ bool is_humnam, to get ture or false
*/
Player::Player(int gold, const bool is_human, int wood, int stone)
{
    is_human_ = is_human;
    gold_ = gold;
    wood_amount_ = wood;
    stone_amount_ = stone;
}
/**
    to update the point of player
    @int x, the number of point
    return NONE;
*/
void Player::ChangePoints(const int x)
{
    points_ = points_ + x;
}

bool Player::afford_resource()
{
    if(wood_amount_ >= 50 && stone_amount_ >= 50)
    {
        return 1;
    }
    return 0;
}
