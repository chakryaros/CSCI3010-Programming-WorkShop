/**
Chakrya Ros
Homework 1
This program is to create the point object and calculate the distance
between the two coordinations.
*/


#ifndef POINT_H
#define POINT_H
#include <iostream>

using namespace std;


class point
{
	public:
		point();
		float find_distance(float x1, float y1, float x2, float y2);
		float getX();
		void setX(float x1);
		float getY();
		void setY(float y1);
		float getZ();
		void setZ(float z1);

	private:
		float x;
		float y;
		float z;
};
#endif