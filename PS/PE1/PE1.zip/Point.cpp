/**
Chakrya Ros
Homework 1
This program is to create the point object and calculate the distance
between the two coordinations.
*/

#include "Point.h"
#include <math.h>
#include <cmath>


/**
    default constructor that take no argument
    @set all variable to zero
*/
point::point()
{
	x = 0;
	y = 0;
	z = 0;
}
/**
    Calcuate the distance between the two points

    @param points. The points of coordination.
    @return distance.
*/
float point::find_distance(float x1, float y1, float x2, float y2 )
{
	x = abs(x1 - x2);
	y = (y1 - y2);
	float dist =0;
	dist = sqrt(pow(x, 2) + pow(y, 2));
	return dist;
}
/**
    get point at x
    @return float x
*/
float point::getX()
{
	return x;
}
/**
    set point at x
    @return nothing
*/
void point::setX(float x1)
{
	x = x1;
}
/**
    get point at y
    @return float y
*/
float point::getY()
{
	return y;
}
/**
    set point at y
    @return nothing
*/
void point::setY(float y1)
{
	y = y1;
}
/**
    get point at z
    @return float z
*/
float point::getZ()
{
	return z;
}
/**
    set point at z
    @return nothing
*/
void point::setZ(float z1)
{
	z = z1;
}